import os
import sys
import random
import string
import subprocess
import logging
import configparser
import asyncio
from aiohttp import ClientSession

# Function to ensure required modules are installed
def install_required_modules():
    required_modules = ["aiohttp"]
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            print(f"Module {module} not found. Installing...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", module])

# Ensure required modules are installed before proceeding
install_required_modules()

# Setup logging
logging.basicConfig(
    filename="dns_processing.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Tambahkan handler untuk mencetak log ke terminal
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)  # Atur level log yang ingin ditampilkan di terminal
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(formatter)
logging.getLogger().addHandler(console_handler)

# Load configuration from config file
config = configparser.ConfigParser()
config.read("config.ini")

MAX_WORKERS = int(config.get("settings", "max_workers", fallback="10"))
RETRIES = int(config.get("settings", "retries", fallback="3"))
INPUT_FILE = config.get("files", "input_file", fallback="datatoken/datatoken.txt")
DONE_FILE = config.get("files", "done_file", fallback="output/done.txt")
DNS_FILE = config.get("files", "dns_file", fallback="output/dns.txt")

# Function to validate DNS record using nslookup or dig
def validate_dns_record(domain_name, expected_ip):
    try:
        logging.info(f"Validasi DNS record untuk {domain_name} dengan IP: {expected_ip}")
        result = subprocess.run(["nslookup", domain_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0 and expected_ip in result.stdout:
            logging.info(f"Validasi sukses untuk {domain_name} menggunakan nslookup.")
            return True
        logging.error(f"Validasi gagal untuk {domain_name} dengan nslookup.")
        result = subprocess.run(["dig", "+short", domain_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0 and expected_ip in result.stdout:
            logging.info(f"Validasi sukses untuk {domain_name} menggunakan dig.")
            return True
        logging.error(f"Validasi gagal untuk {domain_name} dengan dig.")
        return False
    except Exception as e:
        logging.error(f"Error validating DNS record untuk {domain_name}: {e}")
        return False

# Function to add DNS record with fallback between APIs
async def add_dns_record(domain, username, token, record_name, record_type, record_address, retries=RETRIES):
    logging.info(f"Menambahkan DNS record: domain={domain}, record_name={record_name}, type={record_type}, address={record_address}")
    async def uapi():
        url = f"https://{domain}:2083/execute/DNS/add_zone_record"
        headers = {"Authorization": f"cpanel {username}:{token}"}
        data = {"domain": domain, "name": record_name, "type": record_type, "address": record_address}
        async with ClientSession() as session:
            async with session.post(url, headers=headers, data=data, ssl=False) as response:
                return await response.json()

    async def api1_or_2(api_version):
        url = f"https://{domain}:2083/json-api/cpanel"
        headers = {"Authorization": f"cpanel {username}:{token}"}
        params = {
            "cpanel_jsonapi_user": username,
            "cpanel_jsonapi_apiversion": str(api_version),
            "cpanel_jsonapi_module": "ZoneEdit",
            "cpanel_jsonapi_func": "add_zone_record",
            "domain": domain,
            "name": record_name,
            "type": record_type,
            "address": record_address,
        }
        async with ClientSession() as session:
            async with session.get(url, headers=headers, params=params, ssl=False) as response:
                return await response.json()

    for attempt in range(retries):
        try:
            logging.info(f"Percobaan {attempt + 1} untuk menambahkan {record_name}")
            result = await uapi()
            if result.get("status") == 1:
                logging.info(f"Berhasil menambahkan record menggunakan UAPI.")
                return {"success": True, "method": "UAPI"}
            for api_version in (1, 2):
                result = await api1_or_2(api_version)
                if result.get("cpanelresult", {}).get("data"):
                    logging.info(f"Berhasil menambahkan record menggunakan API{api_version}.")
                    return {"success": True, "method": f"API{api_version}"}
        except Exception as e:
            logging.warning(f"Percobaan {attempt + 1} gagal untuk {record_name}: {e}")
    logging.error(f"Gagal menambahkan DNS record untuk {record_name} setelah {retries} kali percobaan.")
    return {"success": False, "message": "All API methods failed after retries"}

# Function to generate a random subdomain name
def generate_random_string_with_word():
    unique_words = config.get("words", "unique_words", fallback="bappeda pemda dinas pusdatin diskominfo").split()
    word = random.choice(unique_words).lower()
    random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=5))
    return f"{word}-{random_suffix}"

# Helper function to process a single DNS record
async def process_single_record(domain, username, token, random_name, ip_address, done_file, dns_file):
    try:
        subdomain = f"{random_name}.{domain}"
        wildcard_subdomain = f"*.{random_name}.{domain}"

        logging.info(f"Memproses DNS record untuk {subdomain}")
        result = await add_dns_record(domain, username, token, random_name, "A", ip_address)
        if not result["success"]:
            logging.error(f"Gagal menambahkan record subdomain '{subdomain}': {result['message']}")
            return None

        wildcard_result = await add_dns_record(domain, username, token, f"*.{random_name}", "A", ip_address)
        if not wildcard_result["success"]:
            logging.error(f"Gagal menambahkan record wildcard '{wildcard_subdomain}': {wildcard_result['message']}")
            return None

        dns_file.write(f"{subdomain} {wildcard_subdomain} ({result['method']})\n")
        done_file.write(f"{domain} - {random_name} ({result['method']})\n")
        dns_file.flush()
        done_file.flush()

        logging.info(f"Berhasil menambahkan DNS record untuk {subdomain}")
        return f"Berhasil menambahkan DNS record untuk {subdomain} menggunakan {result['method']}"
    except Exception as e:
        logging.error(f"Error processing record untuk {domain}: {e}")
        return None

# Main processing function to handle DNS records
async def process_dns_records():
    if not os.path.exists(INPUT_FILE):
        logging.error(f"File '{INPUT_FILE}' tidak ditemukan.")
        return

    ip_address = input("Masukkan IP address untuk DNS record: ").strip()

    with open(INPUT_FILE, "r") as file, open(DONE_FILE, "w") as done_file, open(DNS_FILE, "w") as dns_file:
        tasks = []
        for line in file:
            parts = line.strip().split()
            if len(parts) != 3:
                logging.warning(f"Format baris tidak valid: {line.strip()}")
                continue

            domain, username, token = parts
            random_name = generate_random_string_with_word()

            tasks.append(
                process_single_record(domain, username, token, random_name, ip_address, done_file, dns_file)
            )

        await asyncio.gather(*tasks)

# Main execution block
if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")  # Ignore SSL warnings

    asyncio.run(process_dns_records())
