import os
import sys
import random
import string
import subprocess
import logging
import configparser
import asyncio
from aiohttp import ClientSession

# Function to ensure required modules are installed
def install_required_modules():
    required_modules = ["aiohttp"]
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            print(f"Module {module} not found. Installing...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", module])

# Ensure required modules are installed before proceeding
install_required_modules()

# Setup logging
logging.basicConfig(
    filename="dns_processing.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(formatter)
logging.getLogger().addHandler(console_handler)

# Load configuration from config file
config = configparser.ConfigParser()
config.read("config.ini")

MAX_WORKERS = int(config.get("settings", "max_workers", fallback="10"))
RETRIES = int(config.get("settings", "retries", fallback="3"))
INPUT_FILE = config.get("files", "input_file", fallback="datatoken/datatoken.txt")
DONE_FILE = config.get("files", "done_file", fallback="output/done.txt")
DNS_FILE = config.get("files", "dns_file", fallback="output/dns.txt")

# Function to add DNS record using API1 or API2
async def add_dns_record(domain, username, token, record_name, record_type, record_address, retries=RETRIES):
    logging.info(f"Menambahkan DNS record: domain={domain}, record_name={record_name}, type={record_type}, address={record_address}")
    
    async def api1_or_2(api_version):
        url = f"https://{domain}:2083/json-api/cpanel"
        headers = {"Authorization": f"cpanel {username}:{token}"}
        params = {
            "cpanel_jsonapi_user": username,
            "cpanel_jsonapi_apiversion": str(api_version),
            "cpanel_jsonapi_module": "ZoneEdit",
            "cpanel_jsonapi_func": "add_zone_record",
            "domain": domain,
            "name": record_name,
            "type": record_type,
            "address": record_address,
        }
        async with ClientSession() as session:
            async with session.get(url, headers=headers, params=params, ssl=False) as response:
                return await response.json()

    for attempt in range(retries):
        try:
            logging.info(f"Percobaan {attempt + 1} untuk menambahkan {record_name}")
            for api_version in (1, 2):
                result = await api1_or_2(api_version)
                if result.get("cpanelresult", {}).get("data"):
                    logging.info(f"Berhasil menambahkan record menggunakan API{api_version}.")
                    return {"success": True, "method": f"API{api_version}"}
        except Exception as e:
            logging.warning(f"Percobaan {attempt + 1} gagal untuk {record_name}: {e}")
    
    logging.error(f"Gagal menambahkan DNS record untuk {record_name} setelah {retries} kali percobaan.")
    return {"success": False, "message": "All API methods failed after retries"}

# Function to generate a random subdomain name
def generate_random_string_with_word():
    unique_words = config.get("words", "unique_words", fallback="bappeda bappeda-kab bappeda-kota bappeda-prov pemda pemda-kab pemda-kota pemda-prov dinas dinas-kab dinas-kota dinas-prov diskominfo diskominfo-kab diskominfo-kota diskominfo-prov pusdatin pusdatin-kab pusdatin-kota pusdatin-prov sekretariat setda setwan bkpsdm bkd bppd bpkad dishub disnaker disdik dinkes distan dlh dpmpd dpmptsp dpkp dprkp dpupr dp3a dpsp satpolpp kominfo humas inspektorat perizinan layanan pengaduan keuangan pajak admin portal eoffice layanan opd intranet surat kepegawaian statistik informasi publikasi berita arsip legal laporan monitoring sistem siakad akademik kemahasiswaan perpustakaan siakad skripsi thesis jurnal penelitian lab praktikum repository dosen alumni seminar konferensi admission e-learning beasiswa pmu e-journal ppdb smp sma smk mts ma sd e-rapor perpustakaan alumni siswa guru osis ekstrakurikuler ujian asrama e-learning kurikulum kegiatan info lomba prestasi sekolah praktik pengumuman").split()
    word = random.choice(unique_words).lower()
    random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=5))
    return f"{word}-{random_suffix}"

# Helper function to process a single DNS record
async def process_single_record(domain, username, token, random_name, ip_address, done_file, dns_file):
    try:
        subdomain = f"{random_name}.{domain}"
        wildcard_subdomain = f"*.{random_name}.{domain}"

        logging.info(f"Memproses DNS record untuk {subdomain}")
        result = await add_dns_record(domain, username, token, random_name, "A", ip_address)
        if not result["success"]:
            logging.error(f"Gagal menambahkan record subdomain '{subdomain}': {result['message']}")
            return None

        wildcard_result = await add_dns_record(domain, username, token, f"*.{random_name}", "A", ip_address)
        if not wildcard_result["success"]:
            logging.error(f"Gagal menambahkan record wildcard '{wildcard_subdomain}': {wildcard_result['message']}")
            return None

        dns_file.write(f"{subdomain} {wildcard_subdomain} ({result['method']})\n")
        done_file.write(f"{domain} - {random_name} ({result['method']})\n")
        dns_file.flush()
        done_file.flush()

        logging.info(f"Berhasil menambahkan DNS record untuk {subdomain}")
        return f"Berhasil menambahkan DNS record untuk {subdomain} menggunakan {result['method']}"
    except Exception as e:
        logging.error(f"Error processing record untuk {domain}: {e}")
        return None

# Main processing function to handle DNS records
async def process_dns_records():
    if not os.path.exists(INPUT_FILE):
        logging.error(f"File '{INPUT_FILE}' tidak ditemukan.")
        return

    ip_address = input("Masukkan IP address untuk DNS record: ").strip()

    with open(INPUT_FILE, "r") as file, open(DONE_FILE, "w") as done_file, open(DNS_FILE, "w") as dns_file:
        tasks = []
        for line in file:
            parts = line.strip().split()
            if len(parts) != 3:
                logging.warning(f"Format baris tidak valid: {line.strip()}")
                continue

            domain, username, token = parts
            random_name = generate_random_string_with_word()

            tasks.append(
                process_single_record(domain, username, token, random_name, ip_address, done_file, dns_file)
            )

        await asyncio.gather(*tasks)

# Main execution block
if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")  # Ignore SSL warnings

    asyncio.run(process_dns_records())
