#!/bin/bash

# === Variabel Awal ===
ROOT_FOLDER="/var/www/html"
PHP_VERSION="8.1"
CLOUDFLARE_ENABLED=false
API_TOKEN=""
ZONE_ID=""
EMAIL="admin@example.com"
LOG_FILE="/root/cacatools/script/cacaserver/logs/domain_setup.log"
AUTH_HOOK="/root/cacatools/script/cacaserver/auth-hook.sh"
DOMAINS_FILE="/root/cacatools/output/domains.txt"
CRON_FILE="/etc/cron.d/ssl_renew"
SERVER_IP=$(curl -s ifconfig.me)

# Redirect output ke log file
mkdir -p /root/cacatools/script/cacaserver/logs
exec > >(tee -i $LOG_FILE)
exec 2>&1

# Fungsi: Tampilkan Banner
display_banner() {
    if ! command -v figlet &>/dev/null; then
        echo "[INFO] Instalasi figlet diperlukan untuk menampilkan banner."
        apt update && apt install -y figlet
    fi
    echo
    figlet -c -f standard "SETUP SERVER"
    figlet -c -f slant "BY"
    figlet -c -f slant "CACA-CAYA"
    echo
}

# Fungsi: Periksa Versi Ubuntu
check_ubuntu_version() {
    echo "[INFO] Memeriksa versi Ubuntu..."
    UBUNTU_VERSION=$(lsb_release -rs)
    SUPPORTED_VERSIONS=("18.04" "18.10" "20.04" "20.10" "22.04" "22.10")
    if [[ ! " ${SUPPORTED_VERSIONS[@]} " =~ " ${UBUNTU_VERSION} " ]]; then
        echo "[ERROR] Versi Ubuntu ${UBUNTU_VERSION} tidak didukung. Skrip ini mendukung 18.x, 20.x, dan 22.x."
        exit 1
    fi
    echo "[INFO] Versi Ubuntu ${UBUNTU_VERSION} didukung."
}

# Fungsi: Instalasi Dasar
install_dependencies() {
    echo "[INFO] Memperbarui server dan menginstal kebutuhan..."
    apt update -y && apt upgrade -y || {
        echo "[ERROR] Gagal memperbarui sistem."
        exit 1
    }

    if ! dpkg -l | grep -qw software-properties-common; then
        echo "[INFO] Menginstal software-properties-common..."
        apt install -y software-properties-common || {
            echo "[ERROR] Gagal menginstal software-properties-common."
            exit 1
        }
    fi

    if ! apt-cache policy | grep -q "ondrej/php"; then
        echo "[INFO] Menambahkan PPA Ondřej untuk PHP..."
        add-apt-repository -y ppa:ondrej/php && apt update -y || {
            echo "[ERROR] Gagal menambahkan PPA Ondřej untuk PHP."
            exit 1
        }
    fi

    if ! apt install -y apache2 php${PHP_VERSION} libapache2-mod-php curl ufw certbot python3-certbot-dns-cloudflare unzip wget jq; then
        echo "[ERROR] Gagal menginstal paket-paket yang diperlukan."
        exit 1
    fi
    echo "[INFO] Semua kebutuhan telah terinstal."
}

# Fungsi: Konfigurasi Firewall
configure_firewall() {
    echo "[INFO] Mengonfigurasi firewall..."
    ufw allow 'Apache Full'
    ufw allow OpenSSH
    ufw --force enable || {
        echo "[ERROR] Gagal mengonfigurasi firewall."
        exit 1
    }
    echo "[INFO] Firewall diatur dengan aman."
}

# Fungsi: Periksa IP DNS Domain
check_dns_ip() {
    local DOMAIN=$1
    echo "[INFO] Memeriksa IP DNS untuk domain $DOMAIN..."
    DOMAIN_IP=$(dig +short $DOMAIN | tail -n1)
    if [[ "$DOMAIN_IP" == "$SERVER_IP" ]]; then
        echo "[INFO] IP DNS untuk $DOMAIN cocok dengan IP server ($SERVER_IP)."
        return 0
    else
        echo "[WARNING] IP DNS untuk $DOMAIN ($DOMAIN_IP) tidak cocok dengan IP server ($SERVER_IP)."
        return 1
    fi
}

# Fungsi: Konfigurasi SSL Wildcard
configure_ssl_wildcard() {
    local DOMAIN=$1
    local EMAIL="admin@$DOMAIN"
    echo "[INFO] Mengaktifkan SSL wildcard untuk $DOMAIN..."

    if [ "$CLOUDFLARE_ENABLED" = true ]; then
        echo "[INFO] Menggunakan DNS Cloudflare untuk validasi SSL wildcard..."
        cat <<EOF >/etc/letsencrypt/cloudflare.ini
dns_cloudflare_api_token = $API_TOKEN
EOF
        chmod 600 /etc/letsencrypt/cloudflare.ini

        certbot certonly \
            --dns-cloudflare \
            --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
            -d $DOMAIN -d "*.$DOMAIN" \
            --non-interactive --agree-tos --email $EMAIL
    else
        echo "[INFO] Cloudflare tidak digunakan, memerlukan validasi DNS manual..."
        certbot certonly \
            --manual \
            --preferred-challenges=dns \
            --manual-auth-hook $AUTH_HOOK \
            -d $DOMAIN -d "*.$DOMAIN" \
            --agree-tos --manual-public-ip-logging-ok --email $EMAIL
    fi

    if [ $? -eq 0 ]; then
        echo "[INFO] SSL wildcard diaktifkan untuk $DOMAIN."
        return 0
    else
        echo "[ERROR] Gagal mengaktifkan SSL wildcard untuk $DOMAIN."
        return 1
    fi
}

# Fungsi: Konfigurasi Virtual Host
configure_virtual_host() {
    local DOMAIN=$1
    echo "[INFO] Mengonfigurasi Virtual Host untuk $DOMAIN dan *.${DOMAIN}..."
    mkdir -p ${ROOT_FOLDER}/${DOMAIN}/public_html || {
        echo "[ERROR] Gagal membuat folder root untuk $DOMAIN."
        return 1
    }

    cat <<EOF >/etc/apache2/sites-available/${DOMAIN}.conf
<VirtualHost *:80>
    ServerName $DOMAIN
    ServerAlias *.$DOMAIN
    DocumentRoot ${ROOT_FOLDER}/${DOMAIN}/public_html

    <Directory ${ROOT_FOLDER}/${DOMAIN}/public_html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_access.log combined
</VirtualHost>

<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName $DOMAIN
    ServerAlias *.$DOMAIN
    DocumentRoot ${ROOT_FOLDER}/${DOMAIN}/public_html

    <Directory ${ROOT_FOLDER}/${DOMAIN}/public_html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/$DOMAIN/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/$DOMAIN/privkey.pem

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_ssl_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_ssl_access.log combined
</VirtualHost>
</IfModule>
EOF

    a2ensite ${DOMAIN}.conf || {
        echo "[ERROR] Gagal mengaktifkan Virtual Host untuk $DOMAIN."
        return 1
    }
    systemctl reload apache2 || {
        echo "[ERROR] Gagal me-reload konfigurasi Apache."
        return 1
    }
    echo "[INFO] Virtual Host untuk $DOMAIN telah dikonfigurasi."
}

# Fungsi: Tambah Domain
add_domain() {
    local DOMAIN=$1
    echo "[INFO] Menambahkan domain baru: $DOMAIN"
    if [[ -z "$DOMAIN" ]]; then
        echo "[ERROR] Nama domain tidak boleh kosong."
        return 1
    fi

    if ! check_dns_ip $DOMAIN; then
        echo "[WARNING] Domain $DOMAIN dilewati karena IP DNS tidak cocok dengan IP server."
        return 1
    fi

    if configure_ssl_wildcard $DOMAIN; then
        configure_virtual_host $DOMAIN
        echo "[INFO] Domain $DOMAIN berhasil ditambahkan ke server dengan SSL wildcard."
    else
        echo "[WARNING] SSL wildcard untuk $DOMAIN gagal. Domain tidak akan dikonfigurasi."
        return 1
    fi
}

# Fungsi: Tambah Cron Job untuk Perpanjang SSL
configure_ssl_renewal() {
    echo "[INFO] Menambahkan cron job untuk perpanjang SSL..."
    cat <<EOF >$CRON_FILE
0 3 * * * root certbot renew --quiet --deploy-hook "systemctl reload apache2"
EOF
    chmod 644 $CRON_FILE
    systemctl restart cron || {
        echo "[ERROR] Gagal memulai ulang cron."
        return 1
    }
    echo "[INFO] Cron job untuk perpanjang SSL telah ditambahkan."
}

# Fungsi Utama
main() {
    display_banner
    echo "=== Smart Script: Domain Alias dan SSL Wildcard ==="
    check_ubuntu_version
    install_dependencies
    configure_firewall

    if [[ ! -f "$DOMAINS_FILE" ]]; then
        echo "[ERROR] File $DOMAINS_FILE tidak ditemukan."
        exit 1
    fi

    mapfile -t DOMAINS < "$DOMAINS_FILE"

    if [[ ${#DOMAINS[@]} -eq 0 ]]; then
        echo "[ERROR] Tidak ada domain dalam $DOMAINS_FILE."
        exit 1
    fi

    for DOMAIN in "${DOMAINS[@]}"; do
        echo "=== Memproses domain: $DOMAIN ==="
        if ! add_domain $DOMAIN; then
            echo "[WARNING] Terjadi kesalahan pada domain $DOMAIN. Melanjutkan ke domain berikutnya."
            continue
        fi
        echo "[INFO] Proses selesai untuk domain $DOMAIN."
    done

    configure_ssl_renewal

    systemctl restart apache2
	systemctl start apache2
    a2enmod ssl rewrite
    echo "=== Semua proses selesai. ==="
}

# Jalankan Skrip
main
