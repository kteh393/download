CAYACAYA TOOLS V1 adalah tools untuk di gunakan mengotomatiskan setup server dengan fitur.
- Otomatis Setup Apache2 Dan Module Module Yang di Butuhkan.
- Otomatis Add SSL dan Wildcard SSL Menggunakan Auth Hook Dan Token Api Cpanel.

Integrasi :
- Api Token Cpanel
- Certbot