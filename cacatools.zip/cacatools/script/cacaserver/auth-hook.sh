#!/bin/bash

# === Variabel Awal ===
SCRIPT_PY_PATH="/root/cacatools/script/cacaserver/script.py"
LOG_FILE="/root/cacatools/script/cacaserver/logs/auth-hook.log"

# Redirect output ke log file
mkdir -p /root/cacatools/script/cacaserver/logs
exec > >(tee -i $LOG_FILE)
exec 2>&1

# Fungsi: Tambahkan Record DNS untuk Validasi
add_dns_record() {
    DOMAIN=$CERTBOT_DOMAIN
    TOKEN=$CERTBOT_VALIDATION
    RECORD_NAME="_acme-challenge.${DOMAIN}"

    echo "[INFO] Hook Certbot memproses domain: ${DOMAIN}"
    echo "[INFO] Meneruskan data validation: ${RECORD_NAME} dengan token: ${TOKEN}"

    python3 "$SCRIPT_PY_PATH" "$DOMAIN" "$RECORD_NAME" "$TOKEN"

    if [ $? -eq 0 ]; then
        echo "[INFO] Record DNS TXT berhasil ditambahkan."
    else
        echo "[ERROR] Gagal menambahkan record DNS TXT."
        exit 1
    fi
}

# Fungsi Utama
main() {

    echo "[INFO] Hook Certbot dijalankan."
    add_dns_record
    echo "[INFO] Menunggu propagasi DNS selama 30 detik..."
    sleep 15
}


# Jalankan fungsi utama
main
