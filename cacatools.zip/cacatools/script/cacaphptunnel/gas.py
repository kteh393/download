import os
import tarfile
from datetime import datetime
import random
import pyfiglet
from colorama import Fore, Style, init
import shutil
import subprocess

# Inisialisasi colorama
init(autoreset=True)

def print_banner():
    # Menampilkan banner menggunakan pyfiglet
    print(pyfiglet.figlet_format("PHP TUNNEL", font="standard"))
    print(pyfiglet.figlet_format("CACA-CAYA", font="slant"))
    print("=" * 50)

def create_and_extract_tar(folder_path):
    tar_file_name = "assets_public_thema1_thema2.tar.gz"
    tar_file_path = os.path.join(folder_path, tar_file_name)

    # Membuat arsip tar.gz
    with tarfile.open(tar_file_path, "w:gz") as tar:
        tar.add("script/cacaphptunnel/assets", arcname="assets")
        tar.add("script/cacaphptunnel/thema", arcname="thema")
        tar.add("script/cacaphptunnel/brand_list.txt", arcname="brand_list.txt")

    print(Fore.GREEN + f"Arsip {tar_file_name} berhasil dibuat.")

    # Ekstrak arsip tar.gz langsung ke folder_path
    with tarfile.open(tar_file_path, "r:gz") as tar:
        tar.extractall(path=folder_path)

    print(Fore.GREEN + f"Arsip {tar_file_name} berhasil diekstrak langsung ke folder {folder_path}.")

def generate_php_script(domain, string_tunnel, title, description, folder_path):
    # Generate PHP script dynamically
    used_themes = set()

    def get_random_theme():
        nonlocal used_themes
        while True:
            theme = random.randint(1, 12)
            if theme not in used_themes:
                used_themes.add(theme)
                return theme

    random_theme = get_random_theme()

    php_script = f"""
<?php
$domain = \"{domain}\";
$namaweb = str_replace('.', '-', $domain);
$icon = \"/assets/img/favicon.png\";
$logo = \"/assets/img/logo.png\";
$banner = \"/assets/img/banner.webp\";

$valid_brands = file(\"brand_list.txt\", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$valid_brands) {{
    header(\"HTTP/1.1 404 Not Found\");
    echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
    exit();
}}

function is_valid_brand($input, $valid_brands) {{
    $normalized_input = preg_replace('/[^a-zA-Z0-9]/', '', $input);
    foreach ($valid_brands as $brand) {{
        $normalized_brand = preg_replace('/[^a-zA-Z0-9]/', '', $brand);
        if (strcasecmp($normalized_input, $normalized_brand) === 0) {{
            return true;
        }}
    }}
    return false;
}}

if (isset($_GET['{string_tunnel}'])) {{
    $id = $_GET['{string_tunnel}'];
    if (!is_valid_brand($id, $valid_brands)) {{
        header(\"HTTP/1.1 404 Not Found\");
        echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
        exit();
    }}
    $brand = strtoupper(str_replace('-', ' ', $id));
    $url = \"https://$domain\";
    $amp = \"https://banpolsemogaberuntung.pages.dev/?amp-$namaweb=\" . urlencode($id);
    $canonical = \"https://{domain}/?{string_tunnel}=\" . urlencode($id);

    $title = \"{title}\";
    $description = \"{description}\";
    include(\"thema/\" . {random_theme} . \".php\");
    exit();
}}

if (isset($_SERVER['HTTP_HOST'])) {{
    $host = $_SERVER['HTTP_HOST'];
    if (stripos($host, $domain) !== false) {{
        $subdomain = str_replace(\".$domain\", \"\", $host);
        if (!is_valid_brand($subdomain, $valid_brands)) {{
            header(\"HTTP/1.1 404 Not Found\");
            echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
            exit();
        }}
        $brand = strtoupper(str_replace('-', ' ', $subdomain));
        $amp = \"https://banpolsemogaberuntung.pages.dev/?amp-$namaweb=\" . urlencode($subdomain);
        $canonical = \"https://$subdomain.$domain/\";

        $title = \"{title}\";
        $description = \"{description}\";
        include(\"thema/\" . {random_theme} . \".php\");
        exit();
    }}
}}

header(\"HTTP/1.1 404 Not Found\");
echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
exit();
?>
"""
    index_file_path = os.path.join(folder_path, 'index.php')
    with open(index_file_path, 'w') as f:
        f.write(php_script)

    print(f"Skrip PHP berhasil dibuat di {index_file_path}.")

def generate_sitemap(subdomains, file_name, base_url, url_type, string_tunnel):
    sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n'
    sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

    for subdomain in subdomains:
        if url_type == "brand":
            url = f"https://{base_url}/?{string_tunnel}={subdomain.replace('%2B', '+')}"
        elif url_type == "subdomain":
            formatted_subdomain = subdomain.replace('+', '-')
            url = f"https://{formatted_subdomain}.{base_url}/"
        sitemap += f'  <url>\n'
        sitemap += f'    <loc>{url}</loc>\n'
        sitemap += f'  </url>\n'

    sitemap += '</urlset>\n'

    with open(file_name, 'w') as f:
        f.write(sitemap)

def generate_sitemap_index(total_sitemaps, base_url, file_name, sitemap_type):
    index = '<?xml version="1.0" encoding="UTF-8"?>\n'
    index += '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

    for i in range(1, total_sitemaps + 1):
        if sitemap_type == "subdomain":
            sitemap_url = f"https://{base_url}/subsitemap-{i}.xml"
        elif sitemap_type == "brand":
            sitemap_url = f"https://{base_url}/brandsitemap-{i}.xml"
        lastmod = datetime.now().strftime('%Y-%m-%d')
        index += f'  <sitemap>\n'
        index += f'    <loc>{sitemap_url}</loc>\n'
        index += f'    <lastmod>{lastmod}</lastmod>\n'
        index += f'  </sitemap>\n'

    index += '</sitemapindex>\n'

    with open(file_name, 'w') as f:
        f.write(index)

def generate_robots_txt(base_url, folder_path):
    robots_txt = f"User-agent: *\n"
    robots_txt += "Disallow:\n\n"
    robots_txt += f"Sitemap: https://{base_url}/subsitemap-index.xml\n"
    robots_txt += f"Sitemap: https://{base_url}/brandsitemap-index.xml\n"

    file_path = os.path.join(folder_path, "robots.txt")
    with open(file_path, 'w') as f:
        f.write(robots_txt)

def check_and_setup_user(user, group):
    try:
        # Check if user exists
        subprocess.run(["id", "-u", user], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        print(Fore.YELLOW + f"User '{user}' tidak ditemukan. Membuat user baru...")
        subprocess.run(["sudo", "useradd", "-r", "-d", "/var/www", "-s", "/usr/sbin/nologin", "-g", group, user], check=True)
        print(Fore.GREEN + f"User '{user}' berhasil dibuat.")

def set_permissions_and_ownership(folder_path, user, group):
    print(Fore.YELLOW + "Mengatur permission dan ownership untuk meningkatkan SEO...")

    # Set ownership untuk user dan group yang diberikan
    for root, dirs, files in os.walk(folder_path):
        for dir in dirs:
            shutil.chown(os.path.join(root, dir), user=user, group=group)
        for file in files:
            shutil.chown(os.path.join(root, file), user=user, group=group)

    # Set permission untuk semua folder menjadi 755
    for root, dirs, files in os.walk(folder_path):
        for dir in dirs:
            os.chmod(os.path.join(root, dir), 0o755)

    # Set permission untuk semua file menjadi 644
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            os.chmod(os.path.join(root, file), 0o644)

    # Pastikan file robots.txt memiliki permission 644
    robots_txt_path = os.path.join(folder_path, "robots.txt")
    if os.path.exists(robots_txt_path):
        os.chmod(robots_txt_path, 0o644)

    print(Fore.GREEN + "Permission dan ownership berhasil disesuaikan untuk mendukung SEO!")

def main():
    print_banner()
    domain = input("Masukkan nama domain (contoh: contohwebsite.com): ").strip()
    string_tunnel = input("Masukkan string tunnel (contoh: idr): ").strip()
    title = input("Masukkan judul: ").strip()
    description = input("Masukkan deskripsi: ").strip()

    try:
        with open('script/cacaphptunnel/brand_list.txt', 'r') as f:
            subdomains = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print("Error: File 'brand_list.txt' tidak ditemukan.")
        return

    folder_path = input("Masukkan folder untuk menyimpan file: ").strip()
    os.makedirs(folder_path, exist_ok=True)

    user = "www-data"
    group = "www-data"

    check_and_setup_user(user, group)

    generate_php_script(domain, string_tunnel, title, description, folder_path)
    create_and_extract_tar(folder_path)

    max_urls_per_sitemap = 20000
    total_sitemaps = (len(subdomains) + max_urls_per_sitemap - 1) // max_urls_per_sitemap

    for i in range(1, total_sitemaps + 1):
        subset = subdomains[(i - 1) * max_urls_per_sitemap : i * max_urls_per_sitemap]
        generate_sitemap(
            subset, 
            os.path.join(folder_path, f"brandsitemap-{i}.xml"), 
            domain, 
            "brand",
            string_tunnel
        )
        generate_sitemap(
            subset, 
            os.path.join(folder_path, f"subsitemap-{i}.xml"), 
            domain, 
            "subdomain",
            string_tunnel
        )

    generate_sitemap_index(
        total_sitemaps, 
        domain, 
        os.path.join(folder_path, "subsitemap-index.xml"), 
        "subdomain"
    )
    generate_sitemap_index(
        total_sitemaps, 
        domain, 
        os.path.join(folder_path, "brandsitemap-index.xml"), 
        "brand"
    )

    generate_robots_txt(domain, folder_path)

    # Atur permission dan ownership
    set_permissions_and_ownership(folder_path, user, group)

    print(Fore.GREEN + "Semua langkah selesai! Website siap digunakan.")

if __name__ == "__main__":
    main()
