import os
import sys
import subprocess

# ANSI Escape Codes for Colors
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# Function to ensure required modules are installed
def install_required_modules():
    required_modules = [
        "aiohttp",       # For asynchronous HTTP requests
        "requests",      # For standard HTTP requests
        "configparser"   # For reading configuration files
    ]
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            print(f"{Colors.WARNING}Module {module} not found. Installing...{Colors.ENDC}")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", module])
                print(f"{Colors.OKGREEN}Module {module} successfully installed.{Colors.ENDC}")
            except Exception as e:
                print(f"{Colors.FAIL}Failed to install module {module}: {e}{Colors.ENDC}")
                sys.exit(1)

# Ensure required modules are installed before proceeding
install_required_modules()

# Function to give execution permissions to files
def set_permissions():
    files_to_chmod = [
        "/root/cacatools/script/cacadns/gas.py",
        "/root/cacatools/script/cacasplit/gas.py",
        "/root/cacatools/script/cacaphptunnel/gas.py",
        "/root/cacatools/script/cacaserver/gas.sh",
        "/root/cacatools/script/cacaserver/script.py",
        "/root/cacatools/script/cacaserver/auth-hook.sh",
    ]
    print(f"{Colors.OKCYAN}\nMemproses permission pada file...{Colors.ENDC}")
    for file in files_to_chmod:
        if os.path.exists(file):
            os.system(f"chmod +x {file}")
            print(f"{Colors.OKGREEN}Izin eksekusi diberikan untuk: {file}{Colors.ENDC}")
        else:
            print(f"{Colors.FAIL}File tidak ditemukan: {file}{Colors.ENDC}")
    print(f"{Colors.OKCYAN}Semua permission selesai diproses.{Colors.ENDC}\n")

# Function to display the menu
def display_menu():
    print(f"{Colors.HEADER}=" * 75 + Colors.ENDC)
    print(f"{Colors.OKBLUE}         _________   _________         ___________  _____              ")
    print(f"        / ____/   | / ____/   |       / ____/   \\ \/ /   |             ")
    print(f"       / /   / /| |/ /   / /| |______/ /   / /| |\\  / /| |             ")
    print(f"      / /___/ ___ / /___/ ___ /_____/ /___/ ___ |/ / ___ |             ")
    print(f"      \\____/_/  |_\\____/_/  |_|     \\____/_/  |_/_/_/  |_|             {Colors.ENDC}")
    print(f"{Colors.HEADER}=" * 75 + Colors.ENDC)
    print(f"{Colors.OKGREEN}                            CACACAYA BOT V1{Colors.ENDC}")
    print(f"{Colors.HEADER}=" * 75 + Colors.ENDC)
    print(f"{Colors.OKCYAN}Pilih opsi di bawah ini:\n{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.OKBLUE}1.{Colors.ENDC} Readme Developer")
    print(f"{Colors.BOLD}{Colors.OKBLUE}2.{Colors.ENDC} CAYA DNS Randomizer")
    print(f"{Colors.BOLD}{Colors.OKBLUE}3.{Colors.ENDC} CACA SPLIT TOOLS")
    print(f"{Colors.BOLD}{Colors.OKBLUE}4.{Colors.ENDC} CAYA Mass Domain Deployer")
    print(f"{Colors.BOLD}{Colors.OKBLUE}5.{Colors.ENDC} CACA SEO Tunnel Generator")
    print(f"{Colors.BOLD}{Colors.OKBLUE}6.{Colors.ENDC} Exit")
    print(f"\n{Colors.WARNING}Masukkan pilihan Anda [1-6]:{Colors.ENDC}", end=" ")

# Function to execute menu choices
def execute_choice(choice):
    if choice == "1":
        print(f"\n{Colors.OKCYAN}Readme Developer:{Colors.ENDC}\n")
        print(f"{Colors.BOLD}Struktur folder yang diperlukan:{Colors.ENDC}")
        print(f"{Colors.OKGREEN}/root/cacatools/{Colors.ENDC}")
        print(f"{Colors.OKGREEN}|-- cacacaya.py{Colors.ENDC}")
        print(f"{Colors.OKGREEN}|-- /root/cacatools/script/{Colors.ENDC}")
        print(f"{Colors.OKGREEN}    |-- cacadns/gas.py{Colors.ENDC}")
        print(f"{Colors.OKGREEN}    |-- cacasplit/gas.py{Colors.ENDC}")
        print(f"{Colors.OKGREEN}    |-- cacaphptunnel/gas.py{Colors.ENDC}")
        print(f"{Colors.OKGREEN}    |-- cacaserver/{Colors.ENDC}")
        print(f"{Colors.OKGREEN}        |-- gas.sh{Colors.ENDC}")
        print(f"{Colors.OKGREEN}        |-- script.py{Colors.ENDC}")
        print(f"{Colors.OKGREEN}        |-- auth-hook.sh{Colors.ENDC}")
        print(f"{Colors.OKGREEN}|-- output/{Colors.ENDC}")
        print(f"{Colors.OKGREEN}|-- datatoken/{Colors.ENDC}")
        print(f"\n{Colors.WARNING}Pastikan struktur folder sesuai sebelum menjalankan script!{Colors.ENDC}")
    elif choice == "2":
        print(f"\n{Colors.OKGREEN}Menjalankan CAYA DNS Randomizer...{Colors.ENDC}")
        os.system("python3 /root/cacatools/script/cacadns/gas.py")
    elif choice == "3":
        print(f"\n{Colors.OKGREEN}Menjalankan CACA SPLIT TOOLS...{Colors.ENDC}")
        os.system("python3 /root/cacatools/script/cacasplit/gas.py")
    elif choice == "4":
        print(f"\n{Colors.OKGREEN}Menjalankan CAYA Mass Domain Deployer...{Colors.ENDC}")
        os.system("bash /root/cacatools/script/cacaserver/gas.sh")
    elif choice == "5":
        print(f"\n{Colors.OKGREEN}Menjalankan CACA SEO Tunnel Generator...{Colors.ENDC}")
        os.system("python3 /root/cacatools/script/cacaphptunnel/gas.py")
    elif choice == "6":
        print(f"\n{Colors.OKBLUE}Keluar dari program. Sampai jumpa!{Colors.ENDC}")
        sys.exit(0)
    else:
        print(f"\n{Colors.FAIL}Pilihan tidak valid. Silakan coba lagi.{Colors.ENDC}")

# Main function
def main():
    set_permissions()  # Ensure all files have execution permissions
    while True:
        display_menu()
        choice = input().strip()
        execute_choice(choice)
        print("\n")

if __name__ == "__main__":
    # Ensure the script is run from the correct directory
    current_dir = os.getcwd()
    if not current_dir.endswith("cacatools"):
        print(f"{Colors.FAIL}Error: Skrip ini harus dijalankan dari direktori 'cacatools'.{Colors.ENDC}")
        print(f"{Colors.WARNING}Jalankan perintah berikut untuk berpindah ke direktori yang benar:{Colors.ENDC}")
        print(f"  {Colors.BOLD}cd /root/cacatools{Colors.ENDC}")
        sys.exit(1)
    main()
